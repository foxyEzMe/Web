# Déploiement sur Vercel

## Étapes de déploiement

1. **Créer un compte Vercel**
   - Va sur [vercel.com](https://vercel.com)
   - Connecte-toi avec GitHub

2. **Importer ton projet**
   - Clique sur "New Project"
   - Importe depuis ton repository GitHub
   - Vercel détectera automatiquement que c'est un projet Node.js

3. **Configuration des variables d'environnement**
   Dans les paramètres de ton projet Vercel, ajoute :
   
   - `DATABASE_URL` : Ton URL de base de données PostgreSQL
   - `DISCORD_WEBHOOK_URL` : Ton webhook Discord
   
4. **Déploiement**
   - Clique sur "Deploy"
   - Vercel va automatiquement :
     - Builder ton frontend React
     - Configurer l'API backend
     - Déployer le tout

## Structure du projet pour Vercel

- `api/` : Contient les routes API (serverless functions)
- `dist/public/` : Frontend buildé (généré automatiquement)
- `vercel.json` : Configuration Vercel

## Base de données

Tu auras besoin d'une base de données PostgreSQL. Options recommandées :
- **Neon** (gratuit, optimisé pour Vercel)
- **Supabase** (gratuit)
- **PlanetScale** (MySQL, mais compatible)

## URL finale

Après déploiement, ton site sera disponible sur une URL comme :
`https://ton-projet.vercel.app`