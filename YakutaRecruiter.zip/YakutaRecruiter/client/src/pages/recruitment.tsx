import { useRef, useState } from "react";
import { HeroSection } from "@/components/hero-section";
import { StatsSection } from "@/components/stats-section";
import { RecruitmentForm } from "@/components/recruitment-form";
import { SuccessModal } from "@/components/success-modal";
import { Footer } from "@/components/footer";

export default function RecruitmentPage() {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const scrollToForm = () => {
    formRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleFormSuccess = () => {
    setShowSuccessModal(true);
  };

  return (
    <div className="min-h-screen bg-discord-darkest text-white">
      {/* Header */}
      <header className="bg-discord-darker shadow-lg">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-lg flex items-center justify-center">
                <i className="fas fa-dragon text-white text-xl"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold">Yakuta</h1>
                <p className="text-discord-text-muted text-sm">Serveur Discord</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#" className="text-discord-text hover:text-white transition-colors">Accueil</a>
              <a href="#" className="text-discord-text hover:text-white transition-colors">À propos</a>
              <a href="#" className="text-white font-medium">Recrutement</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <HeroSection onScrollToForm={scrollToForm} />

      {/* Stats Section */}
      <StatsSection />

      {/* Recruitment Form */}
      <div ref={formRef}>
        <RecruitmentForm onSuccess={handleFormSuccess} />
      </div>

      {/* Success Modal */}
      <SuccessModal 
        isOpen={showSuccessModal} 
        onClose={() => setShowSuccessModal(false)} 
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}
