import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SuccessModal({ isOpen, onClose }: SuccessModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-discord-dark border border-success-green/30 p-8 max-w-md">
        <div className="text-center">
          <div className="w-16 h-16 bg-success-green/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-check text-success-green text-2xl"></i>
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">Candidature envoyée !</h3>
          <p className="text-discord-text mb-6">
            Merci pour votre candidature. Notre équipe l'examinera dans les plus brefs délais et vous contactera sur Discord.
          </p>
          <div className="space-y-3">
            <Button 
              onClick={onClose}
              className="w-full bg-success-green text-white py-3 rounded-lg font-medium hover:bg-success-green/90 transition-colors"
            >
              Parfait !
            </Button>
            <a 
              href="https://discord.gg/yakuta" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block w-full text-center text-discord-blue hover:text-white transition-colors"
            >
              <i className="fab fa-discord mr-2"></i>
              Rejoindre le serveur Discord
            </a>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
