import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { applicationSchema, type ApplicationFormData } from "@/lib/validations";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

interface RecruitmentFormProps {
  onSuccess: () => void;
}

export function RecruitmentForm({ onSuccess }: RecruitmentFormProps) {
  const { toast } = useToast();
  const [whyJoinCount, setWhyJoinCount] = useState(0);
  const [whatBringCount, setWhatBringCount] = useState(0);

  const form = useForm<ApplicationFormData>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      pseudo: "",
      age: 18,

      serverTime: "",
      knownStaff: "",
      whyJoin: "",
      whatBring: "",
      previousSanctions: "",
      longTermCommitment: false,
      weeklyAvailability: "",
      activeDaysHours: "",
      voiceCallsAvailable: false,
      previousModeration: "",
      knownBots: "",
      ticketManagement: false,
      clearCommunication: false,
      vocalInsult: "",
      staffAbuse: "",
      sanctionContest: "",
      voiceInterview: false,
      rulesAccepted: false,
      finalRemarks: ""
    }
  });

  const submitMutation = useMutation({
    mutationFn: async (data: ApplicationFormData) => {
      const response = await apiRequest("POST", "/api/applications", data);
      return response.json();
    },
    onSuccess: () => {
      onSuccess();
      form.reset();
      toast({
        title: "Candidature envoyée !",
        description: "Votre candidature a été envoyée avec succès sur Discord.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de l'envoi de la candidature.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: ApplicationFormData) => {
    // Add pulse animation to button
    const button = document.querySelector('button[type="submit"]');
    if (button) {
      button.classList.add('animate-pulse-button');
      setTimeout(() => {
        button.classList.remove('animate-pulse-button');
      }, 600);
    }
    
    submitMutation.mutate(data);
  };

  return (
    <section id="application-form" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            Candidature Staff
          </h2>
          <p className="text-discord-text text-base max-w-2xl mx-auto">
            Remplis ce formulaire pour postuler au staff Yakuta
          </p>
        </div>

        <div className="bg-discord-dark/70 rounded-2xl border border-discord-text/10 p-6 md:p-8">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            
            {/* Infos générales */}
            <div className="space-y-8">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                <i className="fas fa-user text-discord-blue mr-3"></i>
                Infos générales
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <Label htmlFor="pseudo" className="text-discord-text font-medium">
                    Pseudo Discord complet <span className="text-error-red">*</span>
                  </Label>
                  <Input
                    id="pseudo"
                    {...form.register("pseudo")}
                    className="bg-discord-darker/30 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue rounded-lg h-11"
                    placeholder="Nom#0000"
                  />
                  {form.formState.errors.pseudo && (
                    <p className="text-error-red text-sm">{form.formState.errors.pseudo.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="age" className="text-discord-text font-medium">
                    Âge <span className="text-error-red">*</span>
                  </Label>
                  <Input
                    id="age"
                    type="number"
                    {...form.register("age", { valueAsNumber: true })}
                    className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue rounded-xl h-12"
                    placeholder="18"
                  />
                  {form.formState.errors.age && (
                    <p className="text-error-red text-sm">{form.formState.errors.age.message}</p>
                  )}
                </div>
              </div>



              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <Label htmlFor="serverTime" className="text-discord-text font-medium">
                    Depuis quand es-tu sur Yakuta ? <span className="text-error-red">*</span>
                  </Label>
                  <Input
                    id="serverTime"
                    {...form.register("serverTime")}
                    className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue rounded-xl h-12"
                    placeholder="ex: 2 mois, 1 an..."
                  />
                  {form.formState.errors.serverTime && (
                    <p className="text-error-red text-sm">{form.formState.errors.serverTime.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="knownStaff" className="text-discord-text font-medium">
                    Connais-tu quelqu'un dans l'équipe staff ?
                  </Label>
                  <Input
                    id="knownStaff"
                    {...form.register("knownStaff")}
                    className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue rounded-xl h-12"
                    placeholder="Nom du staff ou 'Personne'"
                  />
                </div>
              </div>
            </div>

            {/* Motivation */}
            <div className="space-y-8">
              <div className="flex items-center space-x-4 pb-4 border-b border-discord-blue/20">
                <div className="w-12 h-12 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-xl flex items-center justify-center">
                  <i className="fas fa-heart text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Motivation</h3>
                  <p className="text-discord-text">Pourquoi veux-tu nous rejoindre ?</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="whyJoin" className="text-discord-text font-medium">
                  Pourquoi veux-tu rejoindre le staff Yakuta ? <span className="text-error-red">*</span>
                </Label>
                <Textarea
                  id="whyJoin"
                  {...form.register("whyJoin")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[120px]"
                  placeholder="Explique tes motivations, ce qui t'attire dans la modération..."
                  onChange={(e) => {
                    form.setValue("whyJoin", e.target.value);
                    setWhyJoinCount(e.target.value.length);
                  }}
                />
                <div className="flex justify-between items-center">
                  <div className="text-discord-text-muted text-sm">
                    <span className={whyJoinCount > 800 ? "text-error-red" : ""}>{whyJoinCount}</span>/800 caractères
                  </div>
                </div>
                {form.formState.errors.whyJoin && (
                  <p className="text-error-red text-sm">{form.formState.errors.whyJoin.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="whatBring" className="text-discord-text font-medium">
                  Que penses-tu pouvoir apporter au serveur ? <span className="text-error-red">*</span>
                </Label>
                <Textarea
                  id="whatBring"
                  {...form.register("whatBring")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[100px]"
                  placeholder="Tes compétences, ton expérience, ta personnalité..."
                  onChange={(e) => {
                    form.setValue("whatBring", e.target.value);
                    setWhatBringCount(e.target.value.length);
                  }}
                />
                <div className="text-discord-text-muted text-sm">
                  <span className={whatBringCount > 500 ? "text-error-red" : ""}>{whatBringCount}</span>/500 caractères
                </div>
                {form.formState.errors.whatBring && (
                  <p className="text-error-red text-sm">{form.formState.errors.whatBring.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="previousSanctions" className="text-discord-text font-medium">
                  As-tu déjà eu des sanctions sur ce serveur ou un autre ?
                </Label>
                <Textarea
                  id="previousSanctions"
                  {...form.register("previousSanctions")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[80px]"
                  placeholder="Si oui, lesquelles et pourquoi ? Sinon, écris 'Aucune'"
                />
              </div>

              <div className="flex items-start space-x-3">
                <Checkbox
                  id="longTermCommitment"
                  checked={form.watch("longTermCommitment")}
                  onCheckedChange={(checked) => form.setValue("longTermCommitment", !!checked)}
                  className="border-discord-text/20 mt-1"
                />
                <Label htmlFor="longTermCommitment" className="text-discord-text">
                  Je suis prêt à m'engager sérieusement sur le long terme <span className="text-error-red">*</span>
                </Label>
              </div>
              {form.formState.errors.longTermCommitment && (
                <p className="text-error-red text-sm">{form.formState.errors.longTermCommitment.message}</p>
              )}
            </div>

            {/* Disponibilités */}
            <div className="space-y-8">
              <div className="flex items-center space-x-4 pb-4 border-b border-discord-blue/20">
                <div className="w-12 h-12 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-xl flex items-center justify-center">
                  <i className="fas fa-calendar text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Disponibilités</h3>
                  <p className="text-discord-text">Quand peux-tu être actif ?</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-discord-text font-medium">
                  Disponibilité hebdomadaire <span className="text-error-red">*</span>
                </Label>
                <Select onValueChange={(value) => form.setValue("weeklyAvailability", value)}>
                  <SelectTrigger className="bg-discord-darker/50 border-discord-text/20 text-white rounded-xl h-12">
                    <SelectValue placeholder="Sélectionne tes heures par semaine" />
                  </SelectTrigger>
                  <SelectContent className="bg-discord-dark border-discord-text/20">
                    <SelectItem value="5-10h">5-10 heures/semaine</SelectItem>
                    <SelectItem value="10-20h">10-20 heures/semaine</SelectItem>
                    <SelectItem value="20-30h">20-30 heures/semaine</SelectItem>
                    <SelectItem value="30h+">30+ heures/semaine</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.weeklyAvailability && (
                  <p className="text-error-red text-sm">{form.formState.errors.weeklyAvailability.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="activeDaysHours" className="text-discord-text font-medium">
                  Jours et horaires où tu es le plus actif <span className="text-error-red">*</span>
                </Label>
                <Textarea
                  id="activeDaysHours"
                  {...form.register("activeDaysHours")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[80px]"
                  placeholder="ex: Lundi-Vendredi 18h-22h, Weekend 14h-00h..."
                />
                {form.formState.errors.activeDaysHours && (
                  <p className="text-error-red text-sm">{form.formState.errors.activeDaysHours.message}</p>
                )}
              </div>

              <div className="flex items-start space-x-3">
                <Checkbox
                  id="voiceCallsAvailable"
                  checked={form.watch("voiceCallsAvailable")}
                  onCheckedChange={(checked) => form.setValue("voiceCallsAvailable", !!checked)}
                  className="border-discord-text/20 mt-1"
                />
                <Label htmlFor="voiceCallsAvailable" className="text-discord-text">
                  Je suis disponible pour faire des vocaux staff régulièrement
                </Label>
              </div>
            </div>

            {/* Expérience & compétences */}
            <div className="space-y-8">
              <div className="flex items-center space-x-4 pb-4 border-b border-discord-blue/20">
                <div className="w-12 h-12 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-xl flex items-center justify-center">
                  <i className="fas fa-tools text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Expérience & Compétences</h3>
                  <p className="text-discord-text">Ton background en modération</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="previousModeration" className="text-discord-text font-medium">
                  As-tu déjà été modérateur ou staff Discord ?
                </Label>
                <Textarea
                  id="previousModeration"
                  {...form.register("previousModeration")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[80px]"
                  placeholder="Si oui, où et pendant combien de temps ? Sinon, écris 'Aucune expérience'"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="knownBots" className="text-discord-text font-medium">
                  Quels bots de modération connais-tu ?
                </Label>
                <Input
                  id="knownBots"
                  {...form.register("knownBots")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue rounded-xl h-12"
                  placeholder="ex: MEE6, Dyno, Carl, Wick... ou 'Aucun'"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="ticketManagement"
                    checked={form.watch("ticketManagement")}
                    onCheckedChange={(checked) => form.setValue("ticketManagement", !!checked)}
                    className="border-discord-text/20 mt-1"
                  />
                  <Label htmlFor="ticketManagement" className="text-discord-text">
                    Je sais gérer un ticket et répondre aux demandes
                  </Label>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="clearCommunication"
                    checked={form.watch("clearCommunication")}
                    onCheckedChange={(checked) => form.setValue("clearCommunication", !!checked)}
                    className="border-discord-text/20 mt-1"
                  />
                  <Label htmlFor="clearCommunication" className="text-discord-text">
                    Je sais rédiger des messages clairs (avertissements, annonces...)
                  </Label>
                </div>
              </div>
            </div>

            {/* Cas pratiques */}
            <div className="space-y-8">
              <div className="flex items-center space-x-4 pb-4 border-b border-discord-blue/20">
                <div className="w-12 h-12 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-xl flex items-center justify-center">
                  <i className="fas fa-gavel text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Cas pratiques</h3>
                  <p className="text-discord-text">Comment réagirais-tu dans ces situations ?</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="vocalInsult" className="text-discord-text font-medium">
                  Un membre insulte un autre en vocal, que fais-tu ? <span className="text-error-red">*</span>
                </Label>
                <Textarea
                  id="vocalInsult"
                  {...form.register("vocalInsult")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[100px]"
                  placeholder="Décris ta réaction étape par étape..."
                />
                {form.formState.errors.vocalInsult && (
                  <p className="text-error-red text-sm">{form.formState.errors.vocalInsult.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="staffAbuse" className="text-discord-text font-medium">
                  Un autre staff abuse de ses permissions, comment réagis-tu ? <span className="text-error-red">*</span>
                </Label>
                <Textarea
                  id="staffAbuse"
                  {...form.register("staffAbuse")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[100px]"
                  placeholder="Explique ta démarche..."
                />
                {form.formState.errors.staffAbuse && (
                  <p className="text-error-red text-sm">{form.formState.errors.staffAbuse.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="sanctionContest" className="text-discord-text font-medium">
                  Un joueur conteste une sanction que tu as donnée, que fais-tu ? <span className="text-error-red">*</span>
                </Label>
                <Textarea
                  id="sanctionContest"
                  {...form.register("sanctionContest")}
                  className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[100px]"
                  placeholder="Comment gères-tu cette situation ?"
                />
                {form.formState.errors.sanctionContest && (
                  <p className="text-error-red text-sm">{form.formState.errors.sanctionContest.message}</p>
                )}
              </div>
            </div>

            {/* Engagement */}
            <div className="space-y-8">
              <div className="flex items-center space-x-4 pb-4 border-b border-discord-blue/20">
                <div className="w-12 h-12 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-xl flex items-center justify-center">
                  <i className="fas fa-handshake text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Engagement</h3>
                  <p className="text-discord-text">Dernières confirmations</p>
                </div>
              </div>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="voiceInterview"
                    checked={form.watch("voiceInterview")}
                    onCheckedChange={(checked) => form.setValue("voiceInterview", !!checked)}
                    className="border-discord-text/20 mt-1"
                  />
                  <Label htmlFor="voiceInterview" className="text-discord-text">
                    J'accepte de passer un entretien vocal si nécessaire
                  </Label>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="rulesAccepted"
                    checked={form.watch("rulesAccepted")}
                    onCheckedChange={(checked) => form.setValue("rulesAccepted", !!checked)}
                    className="border-discord-text/20 mt-1"
                  />
                  <Label htmlFor="rulesAccepted" className="text-discord-text">
                    J'ai lu et accepté le règlement du staff <span className="text-error-red">*</span>
                  </Label>
                </div>
                {form.formState.errors.rulesAccepted && (
                  <p className="text-error-red text-sm">{form.formState.errors.rulesAccepted.message}</p>
                )}

                <div className="space-y-2">
                  <Label htmlFor="finalRemarks" className="text-discord-text font-medium">
                    Dernier mot ou remarque ?
                  </Label>
                  <Textarea
                    id="finalRemarks"
                    {...form.register("finalRemarks")}
                    className="bg-discord-darker/50 border-discord-text/20 text-white placeholder-discord-text-muted focus:border-discord-blue resize-none rounded-xl min-h-[80px]"
                    placeholder="Quelque chose d'important à ajouter ?"
                  />
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-8 border-t border-discord-blue/20">
              <Button
                type="submit"
                disabled={submitMutation.isPending}
                className={`w-full bg-gradient-to-r from-discord-blue to-discord-blurple text-white py-4 px-8 rounded-xl font-bold text-lg hover:scale-105 hover:shadow-lg hover:shadow-discord-blue/30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed active:scale-95 relative overflow-hidden ${
                  submitMutation.isPending ? 'animate-pulse' : ''
                }`}
                onClick={(e) => {
                  // Effet de vague au clic
                  const button = e.currentTarget;
                  const rect = button.getBoundingClientRect();
                  const ripple = document.createElement('span');
                  const size = Math.max(rect.width, rect.height);
                  const x = e.clientX - rect.left - size / 2;
                  const y = e.clientY - rect.top - size / 2;
                  
                  ripple.style.cssText = `
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255,255,255,0.6);
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    pointer-events: none;
                  `;
                  
                  button.appendChild(ripple);
                  setTimeout(() => ripple.remove(), 600);
                }}
              >
                {submitMutation.isPending ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3"></div>
                    Envoi en cours...
                  </div>
                ) : (
                  <div className="flex items-center justify-center">
                    <i className="fas fa-paper-plane mr-3 transform transition-transform duration-300 hover:translate-x-1"></i>
                    Envoyer ma candidature
                  </div>
                )}
              </Button>
              
              <p className="text-center text-discord-text-muted text-sm mt-4">
                Ta candidature sera envoyée directement sur Discord
              </p>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}