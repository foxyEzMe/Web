export function Footer() {
  return (
    <footer className="bg-discord-darker border-t border-discord-text/10 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-lg flex items-center justify-center">
                <i className="fas fa-dragon text-white"></i>
              </div>
              <h3 className="font-bold">Yakuta</h3>
            </div>
            <p className="text-discord-text text-sm">
              Une communauté Discord passionnée, dédiée au gaming et aux échanges entre joueurs.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Liens utiles</h4>
            <ul className="space-y-2 text-discord-text text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Règlement du serveur</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Guide des rôles</a></li>
              <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Support</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <div className="space-y-2 text-discord-text text-sm">
              <div className="flex items-center space-x-2">
                <i className="fab fa-discord"></i>
                <span>Yakuta#0001</span>
              </div>
              <div className="flex items-center space-x-2">
                <i className="fas fa-envelope"></i>
                <span>contact@yakuta.com</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-discord-text/10 mt-8 pt-8 text-center text-discord-text text-sm">
          <p>&copy; 2024 Yakuta. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}
