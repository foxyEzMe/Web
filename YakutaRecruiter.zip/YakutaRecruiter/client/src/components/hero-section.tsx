import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  onScrollToForm: () => void;
}

export function HeroSection({ onScrollToForm }: HeroSectionProps) {
  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-discord-dark/50 to-discord-darkest"></div>
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-32 h-32 bg-discord-blue rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-discord-blurple rounded-full blur-3xl animate-float delay-1000"></div>
      </div>
      
      <div className="relative max-w-4xl mx-auto text-center animate-fadeIn">
        <div className="mb-8">
          <div className="inline-flex items-center px-4 py-2 bg-discord-dark/80 rounded-full border border-discord-blue/30 mb-6">
            <i className="fas fa-users text-discord-blue mr-2"></i>
            <span className="text-discord-text">Rejoignez l'équipe Yakuta</span>
          </div>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-black mb-8 bg-gradient-to-r from-white via-discord-blue to-discord-blurple bg-clip-text text-transparent leading-tight">
          Rejoins l'équipe Yakuta
        </h1>
        
        <p className="text-xl md:text-2xl text-discord-text mb-10 max-w-4xl mx-auto leading-relaxed font-medium">
          Tu veux faire partie de notre staff ? Montre-nous de quoi tu es capable et aide à construire la meilleure communauté Discord gaming !
        </p>
        
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <Button 
            onClick={onScrollToForm}
            className="bg-gradient-to-r from-discord-blue to-discord-blurple text-white px-10 py-5 rounded-2xl font-bold text-lg hover:scale-105 hover:shadow-2xl hover:shadow-discord-blue/25 transition-all duration-300 animate-glow"
          >
            <i className="fas fa-rocket mr-3"></i>
            Postuler maintenant
          </Button>
          <Button 
            variant="outline"
            className="border-2 border-discord-blue/50 text-discord-blue px-10 py-5 rounded-2xl font-bold text-lg hover:bg-discord-blue hover:text-white hover:border-discord-blue transition-all duration-300"
            onClick={() => window.open('https://discord.gg/yakuta', '_blank')}
          >
            <i className="fab fa-discord mr-3"></i>
            Rejoindre Discord
          </Button>
        </div>
      </div>
    </section>
  );
}
