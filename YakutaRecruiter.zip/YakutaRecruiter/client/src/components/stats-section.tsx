export function StatsSection() {
  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-discord-dark/50 to-discord-darker/80 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 bg-discord-blue rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-discord-blurple rounded-full blur-3xl animate-float delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-success-green rounded-full blur-3xl animate-float delay-500"></div>
      </div>
      
      <div className="max-w-7xl mx-auto relative">
        <div className="text-center mb-16 animate-fadeIn">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-discord-blue bg-clip-text text-transparent">
            Yakuta en chiffres
          </h2>
          <p className="text-discord-text text-lg max-w-2xl mx-auto">
            Une communauté en pleine croissance qui recherche des talents passionnés
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="text-center animate-slideInUp group">
            <div className="bg-discord-dark/60 backdrop-blur-sm rounded-2xl p-8 border border-discord-blue/20 hover:border-discord-blue/40 transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-discord-blue to-discord-blurple rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-users text-white text-2xl"></i>
              </div>
              <div className="text-4xl font-black text-discord-blue mb-2">150+</div>
              <div className="text-discord-text font-medium">Membres actifs</div>
            </div>
          </div>
          
          <div className="text-center animate-slideInUp delay-200 group">
            <div className="bg-discord-dark/60 backdrop-blur-sm rounded-2xl p-8 border border-success-green/20 hover:border-success-green/40 transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-success-green to-green-400 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-shield-alt text-white text-2xl"></i>
              </div>
              <div className="text-4xl font-black text-success-green mb-2">8</div>
              <div className="text-discord-text font-medium">Staff membres</div>
            </div>
          </div>
          
          <div className="text-center animate-slideInUp delay-400 group">
            <div className="bg-discord-dark/60 backdrop-blur-sm rounded-2xl p-8 border border-discord-blurple/20 hover:border-discord-blurple/40 transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-discord-blurple to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-clock text-white text-2xl"></i>
              </div>
              <div className="text-4xl font-black text-discord-blurple mb-2">24/7</div>
              <div className="text-discord-text font-medium">Support actif</div>
            </div>
          </div>
          
          <div className="text-center animate-slideInUp delay-600 group">
            <div className="bg-discord-dark/60 backdrop-blur-sm rounded-2xl p-8 border border-yellow-500/20 hover:border-yellow-500/40 transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-star text-white text-2xl"></i>
              </div>
              <div className="text-4xl font-black text-yellow-500 mb-2">2</div>
              <div className="text-discord-text font-medium">Ans d'existence</div>
            </div>
          </div>
        </div>
        
        <div className="mt-16 text-center animate-fadeIn">
          <div className="inline-flex items-center px-6 py-3 bg-discord-dark/80 rounded-full border border-discord-blue/30">
            <i className="fas fa-fire text-discord-blue mr-2"></i>
            <span className="text-discord-text font-medium">Nous recrutons activement de nouveaux talents !</span>
          </div>
        </div>
      </div>
    </section>
  );
}
