import { z } from "zod";

export const applicationSchema = z.object({
  // Infos générales
  pseudo: z.string()
    .min(3, "Le pseudo Discord doit contenir au moins 3 caractères"),
  age: z.number()
    .min(13, "L'âge minimum est de 13 ans")
    .max(100, "L'âge maximum est de 100 ans"),

  serverTime: z.string()
    .min(1, "Veuillez indiquer depuis quand vous êtes sur le serveur"),
  knownStaff: z.string().optional(),
  
  // Motivation
  whyJoin: z.string()
    .min(50, "Votre motivation doit contenir au moins 50 caractères")
    .max(800, "Votre motivation ne peut pas dépasser 800 caractères"),
  whatBring: z.string()
    .min(30, "Veuillez détailler ce que vous pouvez apporter (min 30 caractères)")
    .max(500, "Cette réponse ne peut pas dépasser 500 caractères"),
  previousSanctions: z.string().optional(),
  longTermCommitment: z.boolean().refine(val => val === true, {
    message: "Vous devez être prêt à vous engager sur le long terme"
  }),
  
  // Disponibilités
  weeklyAvailability: z.string()
    .min(1, "Veuillez indiquer vos disponibilités hebdomadaires"),
  activeDaysHours: z.string()
    .min(10, "Veuillez détailler vos jours et horaires d'activité")
    .max(300, "Cette réponse ne peut pas dépasser 300 caractères"),
  voiceCallsAvailable: z.boolean(),
  
  // Expérience & compétences
  previousModeration: z.string().optional(),
  knownBots: z.string().optional(),
  ticketManagement: z.boolean(),
  clearCommunication: z.boolean(),
  
  // Cas pratiques
  vocalInsult: z.string()
    .min(20, "Veuillez expliquer votre réaction (min 20 caractères)")
    .max(400, "Cette réponse ne peut pas dépasser 400 caractères"),
  staffAbuse: z.string()
    .min(20, "Veuillez expliquer votre réaction (min 20 caractères)")
    .max(400, "Cette réponse ne peut pas dépasser 400 caractères"),
  sanctionContest: z.string()
    .min(20, "Veuillez expliquer votre réaction (min 20 caractères)")
    .max(400, "Cette réponse ne peut pas dépasser 400 caractères"),
  
  // Engagement
  voiceInterview: z.boolean(),
  rulesAccepted: z.boolean().refine(val => val === true, {
    message: "Vous devez accepter le règlement du staff"
  }),
  finalRemarks: z.string().optional(),
});

export type ApplicationFormData = z.infer<typeof applicationSchema>;
