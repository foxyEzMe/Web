import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertApplicationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Submit recruitment application
  app.post("/api/applications", async (req, res) => {
    try {
      const validatedData = insertApplicationSchema.parse(req.body);
      
      // Store application
      const application = await storage.createApplication(validatedData);
      
      // Send to Discord webhook
      const webhookUrl = process.env.DISCORD_WEBHOOK_URL || process.env.WEBHOOK_URL;
      
      if (webhookUrl) {
        const embed = {
          title: "🎯 Nouvelle Candidature Staff - Yakuta",
          color: 0x5865F2,
          description: `**Candidat:** ${validatedData.pseudo} (${validatedData.age} ans)`,
          fields: [
            {
              name: "🧾 Informations générales",
              value: `**Temps sur le serveur:** ${validatedData.serverTime}\n**Staff connu:** ${validatedData.knownStaff || "Aucun"}`,
              inline: false
            },
            {
              name: "🎙️ Motivation principale",
              value: validatedData.whyJoin.length > 400 
                ? validatedData.whyJoin.substring(0, 400) + "..." 
                : validatedData.whyJoin,
              inline: false
            },
            {
              name: "💡 Ce qu'il apporte",
              value: validatedData.whatBring.length > 300 
                ? validatedData.whatBring.substring(0, 300) + "..." 
                : validatedData.whatBring,
              inline: false
            },
            {
              name: "📆 Disponibilités",
              value: `**Heures/semaine:** ${validatedData.weeklyAvailability}\n**Créneaux actifs:** ${validatedData.activeDaysHours}\n**Vocal staff:** ${validatedData.voiceCallsAvailable ? "✅ Disponible" : "❌ Indisponible"}`,
              inline: false
            },
            {
              name: "🛠️ Expérience & Compétences",
              value: `**Modération précédente:** ${validatedData.previousModeration || "Aucune"}\n**Bots connus:** ${validatedData.knownBots || "Aucun"}\n**Gestion tickets:** ${validatedData.ticketManagement ? "✅" : "❌"}\n**Communication claire:** ${validatedData.clearCommunication ? "✅" : "❌"}`,
              inline: false
            },
            {
              name: "⚠️ Cas pratiques",
              value: `**Insulte en vocal:** ${validatedData.vocalInsult.substring(0, 100)}${validatedData.vocalInsult.length > 100 ? "..." : ""}\n**Abus de staff:** ${validatedData.staffAbuse.substring(0, 100)}${validatedData.staffAbuse.length > 100 ? "..." : ""}`,
              inline: false
            },
            {
              name: "✅ Engagement",
              value: `**Entretien vocal:** ${validatedData.voiceInterview ? "✅ Accepté" : "❌ Refusé"}\n**Engagement long terme:** ${validatedData.longTermCommitment ? "✅ Confirmé" : "❌ Non confirmé"}\n**Sanctions passées:** ${validatedData.previousSanctions || "Aucune"}`,
              inline: false
            }
          ],
          footer: {
            text: `Candidature #${application.id} • Yakuta Staff Recruitment`,
          },
          timestamp: new Date().toISOString()
        };

        if (validatedData.finalRemarks) {
          embed.fields.push({
            name: "💭 Remarques finales",
            value: validatedData.finalRemarks.length > 200 
              ? validatedData.finalRemarks.substring(0, 200) + "..." 
              : validatedData.finalRemarks,
            inline: false
          });
        }

        try {
          const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              embeds: [embed]
            }),
          });

          if (!response.ok) {
            console.error('Failed to send Discord webhook:', response.statusText);
          }
        } catch (error) {
          console.error('Error sending Discord webhook:', error);
        }
      }

      res.json({ 
        success: true, 
        message: "Candidature envoyée avec succès!",
        applicationId: application.id 
      });

    } catch (error) {
      console.error('Error processing application:', error);
      
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          message: "Données invalides",
          errors: error.errors
        });
      } else {
        res.status(500).json({
          success: false,
          message: "Erreur interne du serveur"
        });
      }
    }
  });

  // Get all applications (for admin)
  app.get("/api/applications", async (req, res) => {
    try {
      const applications = await storage.getAllApplications();
      res.json(applications);
    } catch (error) {
      console.error('Error fetching applications:', error);
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération des candidatures"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
