import { applications, type Application, type InsertApplication } from "@shared/schema";

export interface IStorage {
  createApplication(application: InsertApplication): Promise<Application>;
  getApplication(id: number): Promise<Application | undefined>;
  getAllApplications(): Promise<Application[]>;
}

export class MemStorage implements IStorage {
  private applications: Map<number, Application>;
  private currentId: number;

  constructor() {
    this.applications = new Map();
    this.currentId = 1;
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.currentId++;
    const application: Application = {
      id,
      pseudo: insertApplication.pseudo,
      age: insertApplication.age,

      serverTime: insertApplication.serverTime,
      knownStaff: insertApplication.knownStaff || null,
      whyJoin: insertApplication.whyJoin,
      whatBring: insertApplication.whatBring,
      previousSanctions: insertApplication.previousSanctions || null,
      longTermCommitment: insertApplication.longTermCommitment,
      weeklyAvailability: insertApplication.weeklyAvailability,
      activeDaysHours: insertApplication.activeDaysHours,
      voiceCallsAvailable: insertApplication.voiceCallsAvailable,
      previousModeration: insertApplication.previousModeration || null,
      knownBots: insertApplication.knownBots || null,
      ticketManagement: insertApplication.ticketManagement,
      clearCommunication: insertApplication.clearCommunication,
      vocalInsult: insertApplication.vocalInsult,
      staffAbuse: insertApplication.staffAbuse,
      sanctionContest: insertApplication.sanctionContest,
      voiceInterview: insertApplication.voiceInterview,
      rulesAccepted: insertApplication.rulesAccepted,
      finalRemarks: insertApplication.finalRemarks || null,
      submittedAt: new Date().toISOString(),
    };
    this.applications.set(id, application);
    return application;
  }

  async getApplication(id: number): Promise<Application | undefined> {
    return this.applications.get(id);
  }

  async getAllApplications(): Promise<Application[]> {
    return Array.from(this.applications.values());
  }
}

export const storage = new MemStorage();
