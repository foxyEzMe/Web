import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  // Infos générales
  pseudo: text("pseudo").notNull(),
  age: integer("age").notNull(),

  serverTime: text("server_time").notNull(),
  knownStaff: text("known_staff"),
  
  // Motivation
  whyJoin: text("why_join").notNull(),
  whatBring: text("what_bring").notNull(),
  previousSanctions: text("previous_sanctions"),
  longTermCommitment: boolean("long_term_commitment").notNull(),
  
  // Disponibilités
  weeklyAvailability: text("weekly_availability").notNull(),
  activeDaysHours: text("active_days_hours").notNull(),
  voiceCallsAvailable: boolean("voice_calls_available").notNull(),
  
  // Expérience & compétences
  previousModeration: text("previous_moderation"),
  knownBots: text("known_bots"),
  ticketManagement: boolean("ticket_management").notNull(),
  clearCommunication: boolean("clear_communication").notNull(),
  
  // Cas pratiques
  vocalInsult: text("vocal_insult").notNull(),
  staffAbuse: text("staff_abuse").notNull(),
  sanctionContest: text("sanction_contest").notNull(),
  
  // Engagement
  voiceInterview: boolean("voice_interview").notNull(),
  rulesAccepted: boolean("rules_accepted").notNull(),
  finalRemarks: text("final_remarks"),
  
  submittedAt: text("submitted_at").notNull(),
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  submittedAt: true,
});

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;
