# Yakuta Discord Server Staff Recruitment Application

## Overview

This is a full-stack web application for recruiting staff members for the Yakuta Discord server. The application allows potential candidates to submit recruitment forms and automatically forwards applications to Discord via webhooks. It's built with a modern React frontend and Express.js backend, using PostgreSQL for data persistence and Drizzle ORM for database operations.

## System Architecture

The application follows a monorepo structure with separate client and server directories:

- **Frontend**: React with TypeScript, using Vite for development and building
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: shadcn/ui components with Tailwind CSS
- **State Management**: TanStack Query for server state
- **Form Handling**: React Hook Form with Zod validation
- **Deployment**: Replit with autoscale deployment target

## Key Components

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Vite** as the build tool and development server
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for styling with custom Discord-themed colors
- **Wouter** for lightweight client-side routing
- **TanStack Query** for API state management and caching
- **React Hook Form** with Zod resolver for form validation

### Backend Architecture
- **Express.js** server with TypeScript
- **Drizzle ORM** for database operations with PostgreSQL
- **Zod** for runtime type validation
- **REST API** architecture with `/api` endpoints
- **Discord webhook integration** for notifications
- **In-memory storage fallback** when database is not available

### Database Schema
The application uses a single `applications` table with the following structure:
- User information (pseudo, email, age)
- Experience and availability details
- Time slots and skills (stored as JSON arrays)
- Motivation text
- Discord connection status
- Submission timestamp

### External Integrations
- **Discord Webhooks**: Automatic notification to Discord channel when applications are submitted
- **Neon Database**: PostgreSQL hosting (configured via DATABASE_URL)
- **Font Awesome**: Icons for the UI
- **Google Fonts**: Inter font family

## Data Flow

1. **User Submission**: Candidates fill out the recruitment form on the homepage
2. **Client Validation**: Form data is validated using Zod schemas on the client
3. **API Request**: Validated data is sent to `/api/applications` endpoint
4. **Server Validation**: Data is re-validated on the server using shared schemas
5. **Database Storage**: Application is stored in PostgreSQL via Drizzle ORM
6. **Discord Notification**: Webhook sends formatted message to Discord channel
7. **Success Response**: User receives confirmation modal

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver
- **drizzle-orm & drizzle-zod**: Database ORM and Zod integration
- **@tanstack/react-query**: Server state management
- **@hookform/resolvers**: Form validation integration
- **@radix-ui/react-***: Headless UI components
- **wouter**: Lightweight routing
- **zod**: Schema validation
- **date-fns**: Date utilities

### Development Dependencies
- **tsx**: TypeScript execution for development
- **vite**: Build tool and dev server
- **@vitejs/plugin-react**: React support for Vite
- **esbuild**: Production build bundling
- **tailwindcss**: CSS framework
- **typescript**: Type checking

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

- **Development**: `npm run dev` starts both frontend and backend concurrently
- **Build Process**: 
  1. Frontend built with Vite to `dist/public`
  2. Backend bundled with esbuild to `dist/index.js`
- **Production**: `npm run start` serves the built application
- **Database**: PostgreSQL module enabled in Replit environment
- **Port Configuration**: Backend runs on port 5000, mapped to external port 80
- **Auto-scaling**: Configured for autoscale deployment target

The application uses environment variables for configuration:
- `DATABASE_URL`: PostgreSQL connection string
- `DISCORD_WEBHOOK_URL` or `WEBHOOK_URL`: Discord webhook for notifications
- `NODE_ENV`: Environment mode (development/production)

## Changelog

- June 23, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.